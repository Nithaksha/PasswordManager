from configparser import ConfigParser


def config(filename='postgres.ini', section='pwdmanager'):
    # create a parser
    parser = ConfigParser()

    # read config file
    parser.read(filename)

    print(parser.sections())

    # get section, default to postgresql
    db = {}

    if parser.has_section(section):
        params = parser.items(section)
        print(params[0])
        print(params[1])
        print(params[2])
        for param in params:
            db[param[0]] = param[1]

    else:
        raise Exception('Section {0} not found in the {1} file'.format(section, filename))

    return db
config()
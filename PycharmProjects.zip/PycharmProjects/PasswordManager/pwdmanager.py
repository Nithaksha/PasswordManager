import bcrypt
import time
from configparser import ConfigParser

# Global Variables
_filename = 'Config.Ini'
_masterSection = 'master'
_cipherSection = 'cipher'


def check_master_pwd(password: bytes) -> bool:
    """Checks the input password provided by the user with the stored hash and :returns True or False."""

    # create a parser
    _parser = ConfigParser()

    # read config file
    _parser.read(_filename)

    # getting the master password and comparing it with the input password
    if _parser.has_section(_masterSection):
        print(_parser[_masterSection]['masterPwdHash'])
        _master_password = _parser[_masterSection]['masterPwdHash']

        # checking whether the input password and stored hash are equal
        if bcrypt.checkpw(password, _master_password.encode()):
            print('Welcome')
            return True
        else:
            print('Sorry. Try again')
            return False
    else:
        raise Exception('Section {0} not found in the {1} file'.format(_masterSection, _filename))


def get_cipher_key() -> str:
    """ :returns a cipher key for encrypting and decrypting purpose's"""

    # create a parser
    _parser = ConfigParser()

    # read config file
    _parser.read(_filename)

    if _parser.has_section(_cipherSection):
        _cipher_key = _parser[_cipherSection]['cipherKey']
        return _cipher_key

    else:
        raise Exception('Section {0} not found in the {1} file'.format(_masterSection, _filename))


passwd = b's$cret12'

start = time.time()
salt = bcrypt.gensalt(rounds=16)
hashed = bcrypt.hashpw(passwd, salt)
end = time.time()

print(end - start)
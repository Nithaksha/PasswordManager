class User:

    def __init__(self, application: str, password: str, url: str, username=''):
        self.application = application
        self.username = username
        self.password = password
        self.url = url

    def __str__(self):
        print('Application: '+self.application)
        print('Username: '+self.username)
        print('Password: '+self.password)
        print('Applicaton URL: '+self.url)




from secret import get_secret_key
from cryptography.fernet import Fernet
from User import User


user = User('fb', 'fb', 'fb', username='me')

key = Fernet.generate_key()
fer = Fernet(key)
encrypted = fer.encrypt(user.encode())
print(type(encrypted)+': '+encrypted )


import base64
from configparser import ConfigParser
import bcrypt
import User
import os
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

# Global Variables
filepath = f'{os.getcwd()}/CredManager'
masterSection = 'master'
cipherSection = 'cipher'


def hash_it(some_string: str) -> str:
    byte_string = some_string.encode()
    hashed = bcrypt.hashpw(byte_string, bcrypt.gensalt())
    return hashed.decode()


def encrypt_it():
    pass


def create_master(username: str, password: str) -> bool:
    with open(f'{filepath}/{username}.ini', 'w+') as f:
        parser = ConfigParser()
        parser['master'] = {'Username': hash_it(username), 'Password': hash_it(password)}
        parser.write(f)

    if os.path.exists(f'{filepath}/{username}.ini'):
        return True
    else:
        return False


def gen_cipher(username: str, password: str):
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=username.encode(),
        iterations=100000, )
    key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
    parser = ConfigParser()
    parser.read(f'{filepath}/{username}.ini')
    parser.set(masterSection, 'cipher', key.decode())
    with open(f'{filepath}/{username}.ini', 'w') as f:
        parser.write(f)


def check_master(master_username: str, master_password: str) -> bool:
    """Checks the input password provided by the user with the stored hash and :returns True or False."""

    # create a parser
    parser = ConfigParser()

    # read config file
    parser.read(f'{filepath}/{master_username}.ini')

    # getting the master password and comparing it with the input password
    if parser.has_section(masterSection):
        master_hash = parser[masterSection]['Password']

        # checking whether the input password and stored hash are equal
        if bcrypt.checkpw(master_password.encode(), master_hash.encode()):
            print('Welcome')
            return True
        else:
            print('Sorry. please enter correct password')
            return False
    else:
        print('Sorry!! please enter correct username')
        return False


def get_cipher_key(user: User) -> str:
    """ :returns a cipher key for encrypting and decrypting purpose's"""

    # create a parser
    parser = ConfigParser()

    # read config file
    parser.read(f'{filepath}/{user.username}+.ini')

    if parser.has_section(cipherSection):
        cipher_key = parser[cipherSection]['cipherKey']
        return cipher_key

    else:
        raise Exception('Section {0} not found in the {1} file'.format(masterSection, filepath))
